/*
Developer: Depay Ganteng
Ini tampilan bot nya,boleh di rename dll
jangan di jual ye

jangan hapus web developer untuk menghargai Gweh yang udah bikin jing
webdev : https://depay.dev 
*/
const { proto, generateWAMessageFromContent, prepareWAMessageMedia } = require('@whiskeysockets/baileys')
const speed = require('performance-now');

exports.WelcomeMenuDepay = async (depayy, m, pushname, runtime, qtext) => {
    const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = require('@whiskeysockets/baileys')
    let timestamp = speed();
    let latensi = speed() - timestamp;
    //Teks
    let teks = `╭━━•›ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙‹•━━╮
┃╭┈─────────────⩵꙰ཱི࿐
┃╰─🦷⃝⃪𝐓𝐀𝐋𝐊 𝐋𝐄𝐒𝐒 𝐂𝐑𝐀𝐒𝐇𝐄𝐑 ⃝⃪🩸──➤ ↶↷
╰━━•›ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙‹•━━͙✩̣̣̣̣

👋 𝑾𝑬𝑳𝑪𝑶𝑴𝑬, ${pushname}!
𝒀𝒐𝒖 𝒂𝒓𝒆 𝒏𝒐𝒘 𝒄𝒐𝒏𝒏𝒆𝒄𝒕𝒆𝒅 𝒕𝒐 𝒂𝒏 𝒂𝒅𝒗𝒂𝒏𝒄𝒆𝒅 𝑾𝒉𝒂𝒕𝒔𝑨𝒑𝒑 𝑺𝒚𝒔𝒕𝒆𝒎
𝑫𝒆𝒗𝒆𝒍𝒐𝒑𝒆𝒅 & 𝑴𝒂𝒊𝒏𝒕𝒂𝒊𝒏𝒆𝒅 𝒃𝒚 talkless 👩‍💻
𝑻𝒉𝒊𝒔 𝒊𝒔 𝑽𝒊𝒔𝒊𝒐𝒏 1

📊 𝑺𝒀𝑺𝑻𝑬𝑴 𝑺𝑻𝑨𝑻𝑼𝑺
├⤷ 𝑩𝒐𝒕 𝑽𝒆𝒓𝒔𝒊𝒐𝒏: 2.0
├⤷ 𝑩𝒐𝒕 𝑴𝒐𝒅𝒆: Public
├⤷ 𝑷𝒍𝒂𝒕𝒇𝒐𝒓𝒎: Node.js
├⤷ 𝑼𝒑𝒕𝒊𝒎𝒆: ${runtime(process.uptime())}
├⤷ 𝑹𝑨𝑴 𝑼𝒔𝒂𝒈𝒆: ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB
├⤷ 𝑺𝒑𝒆𝒆𝒅: ${latensi.toFixed(4)} detik
└⤷ 𝑺𝒕𝒂𝒕𝒖𝒔: 𝑨𝒄𝒕𝒊𝒗𝒆 🟢

▬▭▬▭▬ ✦✧✦ ▬▭▬▭▬

╭═════════════════════╮
┃    🤖 𝑨𝑰 𝑴𝑶𝑫𝑼𝑳𝑬 🤖
╰═════════════════════╯
│➥ 𝒂𝒊
│➥ 𝒅𝒆𝒑𝒂𝒚
│➥ 𝒅𝒆𝒑𝒂𝒚𝒂𝒊
╰━ ━ ━ ━ ━ ━ ━ ━ ━ ━•⩵꙰ཱི࿐

╭══════════════════════╮
┃     📥 𝑫𝑶𝑾𝑵𝑳𝑶𝑨𝑫𝑬𝑹 📥
╰══════════════════════╯
│➥ 𝒑𝒍𝒂𝒚 
│➥ 𝒚𝒕𝒎𝒑3
│➥ 𝒚𝒕𝒎𝒑4 
│➥ 𝒑𝒍𝒂𝒚𝒄𝒉
│➥ 𝒕𝒕 
│➥ 𝒕𝒕𝒎𝒑3
│➥ 𝒊𝒈
│➥ 𝒊𝒈𝒅𝒍
│➥ 𝒇𝒃
│➥ 𝒔𝒑𝒐𝒕𝒊𝒇𝒚
│➥ 𝒎𝒇
│➥ 𝒎𝒆𝒅𝒊𝒂𝒇𝒊𝒓𝒆
│➥ 𝒄𝒂𝒑𝒄𝒖𝒕
╰━ ━ ━ ━ ━ ━ ━ ━ ━ ━•⩵꙰ཱི࿐

╭═══════════════════════╮
┃    👥 𝑮𝑹𝑶𝑼𝑷 𝑴𝑶𝑫𝑼𝑳𝑬 👥
╰═══════════════════════╯
│➥ 𝒕𝒂𝒈𝒂𝒍𝒍
│➥ 𝒂𝒅𝒅
│➥ 𝒌𝒊𝒄𝒌
│➥ 𝒐𝒑𝒆𝒏𝒈𝒄
│➥ 𝒄𝒍𝒐𝒔𝒆𝒈𝒄
│➥ 𝒍𝒊𝒏𝒌𝒈𝒓𝒖𝒑
│➥ 𝒈𝒆𝒕𝒍𝒊𝒏𝒌𝒈𝒄
│➥ 𝒌𝒖𝒅𝒆𝒕𝒂𝒈𝒄
│➥ 𝒌𝒊𝒄𝒌𝒂𝒍𝒍𝒎𝒆𝒎
│➥ 𝒉𝒊𝒅𝒆𝒕𝒂𝒈
│➥ 𝒉𝒕
╰━ ━ ━ ━ ━ ━ ━ ━ ━ ━•⩵꙰ཱི࿐

╭════════════════════════╮
┃      🛠️ 𝑻𝑶𝑶𝑳𝑺 🛠️
╰════════════════════════╯
│➥ 𝒕𝒐𝒖𝒓𝒍
│➥ 𝒕𝒓𝒂𝒄𝒌𝒊𝒑
│➥ 𝒄𝒆𝒌𝒊𝒅𝒈𝒄
│➥ 𝒄𝒆𝒌𝒊𝒅𝒄𝒉
│➥ 𝒃𝒓𝒂𝒕
│➥ 𝒈𝒆𝒕𝒔𝒐𝒖𝒓𝒄𝒆
│➥ 𝒈𝒆𝒕𝒉𝒕𝒎𝒍
│➥ 𝒕𝒐𝒃𝒂𝒔𝒆64
╰━ ━ ━ ━ ━ ━ ━ ━ ━ ━•⩵꙰ཱི࿐

╭════════════════════════╮
┃     🎮 𝑭𝑼𝑵 𝑴𝑶𝑫𝑼𝑳𝑬 🎮
╰════════════════════════╯
│➥ 𝒄𝒆𝒌𝒌𝒉𝒐𝒅𝒂𝒎
│➥ 𝒄𝒆𝒌𝒌𝒐𝒅𝒂𝒎
│➥ 𝒌𝒊𝒔𝒂𝒉𝒏𝒂𝒃𝒊
╰━ ━ ━ ━ ━ ━ ━ ━ ━ ━•⩵꙰ཱི࿐

╭═══════════════════════╮
┃    💥 𝑩𝑼𝑮 (𝑷𝑹𝑬𝑴𝑰𝑼𝑴) 💥
╰═══════════════════════╯
│➥ 𝒄𝒓𝒂𝒔𝒉𝒅𝒆𝒑
│➥ 𝒄𝒓𝒂𝒔𝒉-𝒊𝒏𝒗𝒊𝒔
│➥ 𝒄𝒓𝒂𝒔𝒉-𝒙
│➥ 𝒊𝒏𝒇𝒊𝒏𝒊𝒕𝒚-𝒄𝒓𝒂𝒔𝒉
│➥ 𝒉𝒂𝒓𝒅-𝒄𝒓𝒂𝒔𝒉
│➥ 𝒄𝒓𝒂𝒔𝒉-𝒙𝒗𝟏
│➥ 𝒇𝒐𝒓𝒙-𝒂𝒏𝒅𝒓𝒐
│➥ 𝒅𝒆𝒍𝒂𝒚-𝒉𝒂𝒓𝒅
│➥ 𝒅𝒆𝒍𝒂𝒚-𝒊𝒏𝒗𝒊𝒔
│➥ 𝒅𝒆𝒍𝒂𝒚-𝒊𝒏𝒇𝒊𝒏𝒊𝒕𝒚
│➥ 𝒅𝒆𝒍𝒂𝒚-𝒑𝒆𝒓𝒎𝒂
│➥ 𝒅𝒆𝒍𝒂𝒚-𝒃𝒖𝒍𝒅𝒐
│➥ 𝒄𝒓𝒂𝒔𝒉-𝒊𝒐𝒔
│➥ 𝒊𝒏𝒗𝒊𝒔-𝒊𝒐𝒔
│➥ 𝒇𝒐𝒓𝒄𝒆-𝒊𝒐𝒔
│➥ 𝒄𝒓𝒂𝒔𝒉𝒈𝒃
│➥ 𝒃𝒗𝒈𝒈𝒃
│➥ 𝒃𝒍𝒂𝒏𝒌𝒈𝒃
╰━ ━ ━ ━ ━ ━ ━ ━ ━ ━•⩵꙰ཱི࿐

╭══════════════════════╮
┃    👑 𝑶𝑾𝑵𝑬𝑹/𝑷𝑹𝑬𝑴𝑰𝑼𝑴 👑
╰══════════════════════╯
│➥ 𝒂𝒅𝒅𝒑𝒓𝒆𝒎
│➥ 𝒅𝒆𝒍𝒑𝒓𝒆𝒎
│➥ 𝒂𝒅𝒅𝒐𝒘𝒏𝒆𝒓
│➥ 𝒅𝒆𝒍𝒐𝒘𝒏𝒆𝒓
│➥ 𝒑𝒖𝒃𝒍𝒊𝒄
│➥ 𝒔𝒆𝒍𝒇
╰━ ━ ━ ━ ━ ━ ━ ━ ━ ━•⩵꙰ཱི࿐

╭══════════════════════╮
┃   ⚠️ SYSTEM DISCLAIMER⚠️
╰══════════════════════╯
│➥ Bug features are for testing & educational purposes only
│➥ Premium & Owner features are restricted to authorized users
│➥ Do not use for spam, abuse, scams, or illegal activities
│➥ Any misuse is fully the responsibility of the user
│➥ Use wisely and respect other users' privacy
│➥ Script protected by license & security system
│
╰━ ━ ━ ━ ━ ━ ━ ━ ━ ━•⩵꙰ཱི࿐`

    // Send as regular image message with caption - THIS WORKS ON ALL VERSIONS
    await depayy.sendMessage(m.chat, {
        image: { url: "https://files.catbox.moe/xg3w4r.jpg" },
        caption: teks,
        contextInfo: {
            externalAdReply: {
                title: '⚝ 🦷⃝⃪𝐓𝐀𝐋𝐊 𝐋𝐄𝐒𝐒 ⃝⃪🩸 - OFFICIAL',
                body: 'talkless Official',
                thumbnailUrl: 'https://files.catbox.moe/xg3w4r.jpg',
                sourceUrl: '',
                mediaType: 1
            },
            isForwarded: true,
            forwardingScore: 999,
            ...qtext.contextInfo,
            quotedMessage: qtext.message
        }
    }, { quoted: qtext });
}

//reply teks
exports.payreply = async (teks, lol, m, depayy, proto) => {
    let msgii = generateWAMessageFromContent(m.chat, { 
        viewOnceMessage: { 
            message: { 
                "messageContextInfo": { 
                    "deviceListMetadata": {}, 
                    "deviceListMetadataVersion": 2
                }, 
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    contextInfo: { 
                        mentionedJid: [m.sender], 
                        isForwarded: true,
                        forwardingScore: 999,
                        ...lol.contextInfo,
                        quotedMessage: lol.message,
                        externalAdReply: {
                            showAdAttribution: false,
                            title: 'talkless Official Notification',
                            body: 'V2.0 NEW ERA',
                            thumbnailUrl: 'https://depay.dev/levi.jpg',
                            sourceUrl: 'https://youtube.com/@DepayAsli'
                        }
                    }, 
                    body: proto.Message.InteractiveMessage.Body.create({ 
                        text: teks
                    }), 
                    footer: proto.Message.InteractiveMessage.Footer.create({ 
                        text: "\`⚝ 𝐓𝐀𝐋𝐊𝐋𝐄𝐒𝐒 - OFFICIAL\`"
                    }), 
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
                        buttons: [{
                            "name": "cta_url",
                            "buttonParamsJson": JSON.stringify({
                                "display_text": "Get Script!",
                                "url": "https://depay.dev",
                                "merchant_url": "https://www.google.com"
                            })
                        }]
                    }) 
                }) 
            } 
        } 
    }, { userJid: m.sender, quoted: lol });

    await depayy.relayMessage(msgii.key.remoteJid, msgii.message, { 
        messageId: msgii.key.id 
    });
}

//Tampilan 2
exports.MenuBotDepay2 = async (depayy, m, pushname, runtime, qtext) => {
    let timestamp = speed();
    let latensi = speed() - timestamp;
    let teks = `Welcome back, *${pushname}*.
    
Hi, I'm a bot created by \`𝐓𝐀𝐋𝐊𝐋𝐄𝐒𝐒\` , This bot is specifically designed to attack, manage groups, provide useful tools, offer fun interactions, and help you create panels. Use this bot wisely; it is strictly prohibited to use these features to harm others.

—  *INFORMATION* —
Release: *2.0* 
Developer: *Depay*
Youtube: @DepayAsli
Type: case
Visibility: Global
Trigger: .
Library: Baileys
Github: depay1221 
Telegram: @DepayAsli
Tiktok: @payeyeye_
Action: https://ẉ.depay/dev
Runtime: ${runtime(process.uptime())}
🚀 : ${latensi.toFixed(4)} detik
GetScript: https://depay.dev

— *Forclose Android*
 .crash-invis - *Target*
 .crash-x - *Target*
 .infinity-crash - *Target*
 .hard-crash - *Target*
 .crash-xv1 - *Target*
 .forx-andro - *Target*
 .crashdep - *Target*

— *Delay Android*
 .delay-hard - *Target*
 .delay-invis - *Target*
 .delay-infinity - *Target*
 .delay-perma - *Target*
 .delay-buldo - *Target*

— *Forclose IOS*
 .crash-ios - *Target*
 .invis-ios - *Target*
 .force-ios - *Target*

— *Bug Group*
 .crashgb - *Link-Group*
 .bvggb - *Link-Group*
 .blankgb - *Link-Group*

— *Add Acces*
 .addprem *Number*
 .delprem *Number*
 .addowner *Number*
 .delowner *Number*
 .self
 .public
 ` 
    const headerImage = await prepareWAMessageMedia(
        { image: { url: "https://depay.dev/foto.jpeg" } },
        { upload: depayy.waUploadToServer }
    );

    const interactiveMessage = proto.Message.InteractiveMessage.create({
        body: proto.Message.InteractiveMessage.Body.create({
            text: teks
        }),
        footer: proto.Message.InteractiveMessage.Footer.create({
            text: `\`⚝ 𝐓𝐀𝐋𝐊𝐋𝐄𝐒𝐒 - OFFICIAL\``
        }),
        header: proto.Message.InteractiveMessage.Header.create({
            title: ``,
            hasMediaAttachment: true,
            imageMessage: headerImage.imageMessage
        }),
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            messageParamsJson: JSON.stringify({
                limited_time_offer: {
                    text: "⚝ 𝐓𝐀𝐋𝐊𝐋𝐄𝐒𝐒 - OFFICIAL",
                    url: "https://depay.dev",
                    copy_code: "https://depay.dev",
                    expiration_time: Date.now() * 999
                },
                bottom_sheet: {
                    in_thread_buttons_limit: 2,
                    divider_indices: [1, 2, 3, 4, 5, 999],
                    list_title: "⚝ 𝐓𝐀𝐋𝐊𝐋𝐄𝐒𝐒 - DEV",
                    button_title: "⚝ 𝐓𝐀𝐋𝐊𝐋𝐄𝐒𝐒 "
                },
                tap_isTarget_configuration: {
                    title: " X ",
                    description: "bomboclard",
                    canonical_url: "https://depay.dev",
                    domain: "https://depay.dev",
                    button_index: 0
                }
            }),
            buttons: [
                {
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: "— YouTube —",
                        url: "https://youtube.com/@DepayAsli"
                    })
                },
                {
                    name: "single_select",
                    buttonParamsJson: JSON.stringify({
                        title: "— Show Fiture —",
                        sections: [
                            {
                                title: "— Public Fiture —",
                                rows: [{
                                    title: "Show Command",
                                    description: "© DepayDeveloper",
                                    id: ".allmnu"
                                }]
                            }, 
                            {
                                title: "— Contact Developer —",
                                rows: [{
                                    title: "Kontak Dev",
                                    description: "© DepayDeveloper",
                                    id: ".dev"
                                }]
                            }, 
                            {
                                title: "— Credit Script —",
                                rows: [{
                                    title: "Spesial Support",
                                    description: "© DepayDeveloper",
                                    id: ".tqto"
                                }]
                            }
                        ]
                    })
                },
                {
                    name: "cta_url", 
                    buttonParamsJson: JSON.stringify({ 
                        display_text: "— Website Dev —", 
                        url: "https://depay.dev" 
                    }) 
                },
                { 
                    name: "cta_url", 
                    buttonParamsJson: JSON.stringify({ 
                        display_text: "— Info Script —", 
                        url: "https://whatsapp.com/channel/0029Vb7zxXq7oQhl0tOf7417" 
                    }) 
                },
                {
                    name: "galaxy_message",
                    buttonParamsJson: JSON.stringify({
                        icon: "GIFT",
                        flow_cta: "— Thank you for using this bot :>",
                        flow_message_version: "3"
                    })
                },
                {
                    name: "galaxy_message",
                    buttonParamsJson: JSON.stringify({
                        icon: "GIFT",
                        flow_cta: "〢 Developer: depay.dev ", //jangan di hapus
                        flow_message_version: "3"    
                    })
                },
                {
                    name: "galaxy_message",
                    buttonParamsJson: JSON.stringify({
                        icon: "GIFT",
                        flow_cta: "〢 Spesial Support: Aaiiurs🌻", //jangan di hapus
                        flow_message_version: "3"                
                    })
                },
                {
                    name: "galaxy_message",
                    buttonParamsJson: JSON.stringify({
                        icon: "GIFT",
                        flow_cta: "                            © depay.dev            ",
                        flow_message_version: "3"          
                    })
                }
            ]
        }),
        contextInfo: {
            externalAdReply: {
                showAdAttribution: false,
                renderLargerThumbnail: true,
                title: 'New ERA',
                body: 'Depay Official',
                previewType: 'VIDEO',
                thumbnailUrl: 'https://depay.dev/levi.jpg',
                sourceUrl: 'https://depay.dev'
            },
            isForwarded: true,
            forwardingScore: 999,
            ...qtext.contextInfo,
            quotedMessage: qtext.message
        }
    });

    const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: interactiveMessage
            }
        }
    }, { 
        quoted: qtext 
    });

    await depayy.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
 {
 await new Promise(resolve => setTimeout(resolve, 1000));
        await depayy.sendMessage(m.chat, {
            audio: { url: "https://depay.dev/depaymusik.mp3" },
            mimetype: "audio/mp4",
            ptt: true,
            contextInfo: {
                externalAdReply: {
                    title: '⚝ 𝐓𝐀𝐋𝐊𝐋𝐄𝐒𝐒 - OFFICIAL',
                    body: '© Depayy',
                    thumbnailUrl: 'https://depay.dev/foto.jpeg',
                    sourceUrl: 'https://depay.dev',
                    mediaType: 1,
                    renderLargerThumbnail: false
                },
                ...qtext.contextInfo,
                quotedMessage: qtext.message
            }
        }, { 
            quoted: qtext
        });
    }
} 


//tampilan 3
exports.MenuBotDepay3 = async (depayy, m, pushname, runtime, qtext) => {
    let timestamp = speed();
    let latensi = speed() - timestamp;
    let teks = `Welcome back, *${pushname}*.
    
Hi, I'm a bot created by \`𝐓𝐀𝐋𝐊𝐋𝐄𝐒𝐒\` , This bot is specifically designed to attack, manage groups, provide useful tools, offer fun interactions, and help you create panels. Use this bot wisely; it is strictly prohibited to use these features to harm others.

—  *INFORMATION* —
Release: *2.0* 
Developer: *Depay*
GetScript: https://depay.dev
Youtube: @DepayAsli
Type: case
Visibility: Global
Trigger: .
Library: Baileys
Github: depay1221 
Telegram: @DepayAsli
Tiktok: @payeyeye_
Runtime: ${runtime(process.uptime())}
SpeedBot : ${latensi.toFixed(4)} detik

— *Command Fiture*
 .capcut *Url*
 .tiktok *Url*
 .ytmp3 *Url*
 .ytmp4 *Url*
 .igdl *Url*
 .spotify *Url*
 .mediafire *Url*
 .play *Judul*
 .gethtml *Link*
 .trackip *IP*
 .brat *Promt* 
 .depayai *Promt*
 .cekkhodam *Nama* 
 .kisahnabi *namanabi*
 .tobase64 *Teks*
 .tourl *Reply image*
 .cekidch *Url* 
 .add *Nomor*
 .kick *Tag/Reply*
 .opengc *Buka Grup*
 .closegc *Tutup Grup*
 .kudegc *Kick Allmem* 
 .hidetag *Teks*
 .tagall *Teks*
                             
— *Cpanel Fiture*
 .1gb *Username*
 .2gb *Username*
 .3gb *Username*
 .4gb *Username*
 .5gb *Username*
 .6gb *Username*
 .7gb *Username*
 .8gb *Username*
 .9gb *Username*
 .unli *Username*
 .cadmin *Username*
 .listserver *Cek Server*
 .listuser *Cek User*
 .listadmin *Cek Admin*
 .delpanel *ID*
 .deluser *ID*
 .deladmin *ID*
 .addrespanel *Nomor*
 .delrespanel *Nomor*
 .addadmin *Nomor*
 .deladmin *Nomor*

— Thank you for using this bot :>
 `  
    const headerImage = await prepareWAMessageMedia(
        { image: { url: "https://depay.dev/foto.jpeg" } },
        { upload: depayy.waUploadToServer }
    );

    const interactiveMessage = proto.Message.InteractiveMessage.create({
        body: proto.Message.InteractiveMessage.Body.create({
            text: teks
        }),
        footer: proto.Message.InteractiveMessage.Footer.create({
            text: `\`⚝ 𝐓𝐀𝐋𝐊𝐋𝐄𝐒𝐒 - OFFICIAL\``
        }),
        header: proto.Message.InteractiveMessage.Header.create({
            title: ``,
            hasMediaAttachment: true,
            imageMessage: headerImage.imageMessage
        }),
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            messageParamsJson: JSON.stringify({
                limited_time_offer: {
                    text: "⚝ 𝐓𝐀𝐋𝐊𝐋𝐄𝐒𝐒 - OFFICIAL",
                    url: "https://depay.dev",
                    copy_code: "https://depay.dev",
                    expiration_time: Date.now() * 999
                },
                bottom_sheet: {
                    in_thread_buttons_limit: 2,
                    divider_indices: [1, 2, 3, 4, 5, 999],
                    list_title: "⚝ 𝐓𝐀𝐋𝐊𝐋𝐄𝐒𝐒 - DEV",
                    button_title: "⚝ 𝐓𝐀𝐋𝐊𝐋𝐄𝐒𝐒 "
                },
                tap_isTarget_configuration: {
                    title: " X ",
                    description: "bomboclard",
                    canonical_url: "https://depay.dev",
                    domain: "https://depay.dev",
                    button_index: 0
                }
            }),
            buttons: [
                {
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: "— YouTube —",
                        url: "https://youtube.com/@DepayAsli"
                    })
                },
                {
                    name: "single_select",
                    buttonParamsJson: JSON.stringify({
                        title: "— Show Fiture —",
                        sections: [
                            {
                                title: "— Private Fiture —",
                                rows: [{
                                    title: "Show Command",
                                    description: "© DepayDeveloper",
                                    id: ".bvgmenu"
                                }]
                            }, 
                            {
                                title: "— Contact Developer —",
                                rows: [{
                                    title: "Kontak Dev",
                                    description: "© DepayDeveloper",
                                    id: ".dev"
                                }]
                            }, 
                            {
                                title: "— Credit Script —",
                                rows: [{
                                    title: "Spesial Support",
                                    description: "© DepayDeveloper",
                                    id: ".tqto"
                                }]
                            }
                        ]
                    })
                },
                {
                    name: "cta_url", 
                    buttonParamsJson: JSON.stringify({ 
                        display_text: "— Website Dev —", 
                        url: "https://depay.dev" 
                    }) 
                },
                { 
                    name: "cta_url", 
                    buttonParamsJson: JSON.stringify({ 
                        display_text: "— Info Script —", 
                        url: "https://whatsapp.com/channel/0029Vb7zxXq7oQhl0tOf7417" 
                    }) 
                },
                {
                    name: "galaxy_message",
                    buttonParamsJson: JSON.stringify({
                        icon: "GIFT",
                        flow_cta: "— Thank you for using this bot :>",
                        flow_message_version: "3"
                    })
                },
                {
                    name: "galaxy_message",
                    buttonParamsJson: JSON.stringify({
                        icon: "GIFT",
                        flow_cta: "〢 Developer: depay.dev ", //jangan di hapus
                        flow_message_version: "3"    
                    })
                },
                {
                    name: "galaxy_message",
                    buttonParamsJson: JSON.stringify({
                        icon: "GIFT",
                        flow_cta: "〢 Spesial Support: Aaiiurs🌻", //jangan di hapus
                        flow_message_version: "3"                
                    })
                },
                {
                    name: "galaxy_message",
                    buttonParamsJson: JSON.stringify({
                        icon: "GIFT",
                        flow_cta: "                            © depay.dev          ",
                        flow_message_version: "3"          
                    })
                }
            ]
        }),
        contextInfo: {
            externalAdReply: {
                showAdAttribution: false,
                renderLargerThumbnail: true,
                title: 'New ERA',
                body: 'Depay Official',
                previewType: 'VIDEO',
                thumbnailUrl: 'https://depay.dev/levi.jpg',
                sourceUrl: 'https://depay.dev'
            },
            isForwarded: true,
            forwardingScore: 999,
            ...qtext.contextInfo,
            quotedMessage: qtext.message
        }
    });

    const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: interactiveMessage
            }
        }
    }, { 
        quoted: qtext 
    });

    await depayy.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
 {
 await new Promise(resolve => setTimeout(resolve, 1000));
        await depayy.sendMessage(m.chat, {
            audio: { url: "https://depay.dev/depaymusik.mp3" },
            mimetype: "audio/mp4",
            ptt: true,
            contextInfo: {
                externalAdReply: {
                    title: '⚝ 𝐓𝐀𝐋𝐊𝐋𝐄𝐒𝐒 - OFFICIAL',
                    body: '© Depayy',
                    thumbnailUrl: 'https://depay.dev/foto.jpeg',
                    sourceUrl: 'https://depay.dev',
                    mediaType: 1,
                    renderLargerThumbnail: false
                },
                ...qtext.contextInfo,
                quotedMessage: qtext.message
            }
        }, { 
            quoted: qtext
        });
    }
} 